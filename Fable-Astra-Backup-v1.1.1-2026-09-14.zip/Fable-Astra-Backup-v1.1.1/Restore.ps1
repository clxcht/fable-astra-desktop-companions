$ErrorActionPreference = 'Stop'
$backupSettings = Join-Path $PSScriptRoot 'Backup\settings.json'
$backupMetadata = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Backup\metadata.json') -Raw | ConvertFrom-Json
$companionRoot = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'FableAstra'
$companionExe = Join-Path $companionRoot 'App\FableAstra.exe'

# Fully stop the installed copy before restoring its files.
$running = @(Get-Process -Name FableAstra -ErrorAction SilentlyContinue | Where-Object Path -EQ $companionExe)
foreach ($process in $running) {
    Stop-Process -InputObject $process
    if (-not $process.WaitForExit(5000)) { throw 'The installed companions did not finish closing.' }
}
New-Item -ItemType Directory -Path $companionRoot -Force | Out-Null
$currentSettings = Join-Path $companionRoot 'settings.json'
if (Test-Path -LiteralPath $currentSettings) {
    $previousSettings = Join-Path $companionRoot ('settings.before-restore.' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '.json')
    Copy-Item -LiteralPath $currentSettings -Destination $previousSettings
}
if (Test-Path -LiteralPath $backupSettings) {
    Copy-Item -LiteralPath $backupSettings -Destination $currentSettings -Force
}
& (Join-Path $PSScriptRoot 'Install.ps1')
if (-not $backupMetadata.StartupEnabled) {
    Remove-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name FableAstra -ErrorAction SilentlyContinue
}
Write-Output 'Restored the saved app, artwork, preferences and startup setting.'
