# Fable + Astra — exact setup backup

Version **1.1.1**, saved September 14, 2026.

## Restore this setup

1. Extract the entire ZIP to a folder.
2. Double-click **Restore.cmd**.

This restores the saved application, every sprite, your preferences and the saved Windows startup setting, then launches the companions. An existing preferences file is kept as a timestamped `settings.before-restore.*.json` before replacement.

To install the application while retaining your existing preferences instead, run **Install.cmd**. To run it directly, open **FableAstra/FableAstra.exe** with all neighboring files left in place.

This is the **Windows ARM64** build for your current computer. It uses the **.NET 8 Windows Desktop Runtime** already installed on this computer. Source code and a build script are included for rebuilding for other Windows architectures.

Included: the working app, original and generated artwork, source code, documentation, verification reports, saved preferences in `Backup/settings.json`, backup metadata, and `SHA256SUMS.txt` integrity hashes. API-key values are stored outside the app and are not included in this backup.

See **README.md** for controls and behavior.
